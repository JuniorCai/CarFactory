﻿using System.Web.Mvc;

namespace NbscwMPACarFactory.Web.Controllers
{
    public class AboutController : NbscwMPAControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}