using NbscwMPACarFactory.Configuration.Ui;

namespace NbscwMPACarFactory.Web.Models.Layout
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}